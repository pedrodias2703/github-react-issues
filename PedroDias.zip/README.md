### Usage:

1. `npm install`
2. `npm start`

### Tests

Sorry, I could not implement as much tests as I wanted to. Anyway, to test the app, run:
`npm test`
